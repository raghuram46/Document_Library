package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class MainDemo {

	public static void main(String[] args) {
		
//		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
//		Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
//		SessionFactory factory = meta.getSessionFactoryBuilder().build();
//		Session session = factory.openSession();
//		Transaction t = session.beginTransaction();
//		Employee e1 = new Employee();
//		e1.setFirstName("Gaurav");
//		e1.setLastName("Chawla1");
//		session.save(e1);
//		//System.out.println(session.load(Employee.class, 1));
//			t.commit();	
//		System.out.println("successfully saved");
//		factory.close();
//		session.close();	
		
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		Employee e1 = new Employee();
		e1.setFirstName("Gaurav");
		e1.setLastName("Chawla");
		session.save(e1);
		t.commit();
		sf.close();
		session.close();
		

	}
}

package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Address;
import com.model.Employee;

public class SetterInjectionMain {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/config/springconfig.xml");
		
		Employee employee1 = (Employee) applicationContext.getBean("employee1");
		
		System.out.println("Employee Details");
		System.out.println(employee1.getId());
		System.out.println(employee1.getName());
		System.out.println(employee1.getSalary());
		System.out.println("--------------------");
		System.out.println("Employee Address Details");
		Address address = employee1.getAddress();

		System.out.println(address.getAddId());
		System.out.println(address.getDoorNo());
		System.out.println(address.getStreet());
		System.out.println(address.getPinCode());
		System.out.println("//////////////");
		
		
	}

}

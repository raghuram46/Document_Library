package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Config;
import com.model.Employee;

public class SpringAnnotationBased {

	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(Config.class);
		Employee emp1 = (Employee) applicationContext.getBean(Employee.class);
		System.out.println(emp1.getId());
		System.out.println((emp1.getName()));
		System.out.println(emp1.getSalary());
		
		System.out.println("///////////////////////");
//		Address add1 = (Address) applicationContext.getBean(Address.class);
//		System.out.println(add1.getAddId());
//		System.out.println(add1.getDoorNo());
//		System.out.println(add1.getStreet());
	
	}

}

package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import com.model.Address;
import com.model.Employee;

@Configuration
@ComponentScan(basePackages = "com.model")
public class Config {

	//@Bean
	public Employee get() {
		//System.out.println("Employee Object Created");
		return new Employee();
	}
	//@Bean
	public Address getAddress() {
		//System.out.println("Address Object Created");
		return new Address();
	}
}

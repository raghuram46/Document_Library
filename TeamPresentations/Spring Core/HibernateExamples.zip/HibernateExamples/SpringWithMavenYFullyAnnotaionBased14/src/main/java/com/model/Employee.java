package com.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	@Value(value = "1")
	private int id;
	@Value(value = "Kiruba")
	private String name;
	@Value(value = "5000f")
	private float salary;

	public Employee() {
		super();
	}

	public Employee(@Value(value="5") int id,@Value(value="Nithin") String name,@Value(value="5555f") float salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}
	//@Value(value = "1")
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

}

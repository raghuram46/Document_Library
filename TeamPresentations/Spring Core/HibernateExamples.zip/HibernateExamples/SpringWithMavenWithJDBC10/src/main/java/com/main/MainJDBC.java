package com.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.MySQLConnectionCheck;
import com.model.Employee;

public class MainJDBC {

	public static void main(String[] args) {
		
		 ApplicationContext ctx=new ClassPathXmlApplicationContext("com/config/springconfig.xml");  
	      
		    Employee emp=(Employee)ctx.getBean("employee"); 
		    emp.setId(12);
		    emp.setName("Kiruba");
		    emp.setSalary(2000f);
		    
		 Connection con = MySQLConnectionCheck.getConnection();
		 String sql = " insert into employee (id,name,salary)"
				    + " values (?, ?, ?)";
		 try {
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, emp.getId());
			st.setString(2, emp.getName());
			st.setFloat(3, emp.getSalary());		
			st.execute();
			System.out.println("Inserted");
			
			
//			String readquery = "select * from employee where id = ?";
//			PreparedStatement preparedStatement = con.prepareStatement(readquery);
//			preparedStatement.setInt(1, 11);
//			ResultSet resultSet = preparedStatement.executeQuery();
//	        while(resultSet.next())
//	        {
//	           System.out.println(resultSet.getInt(1));
//	           System.out.println(resultSet.getString(2));
//	           System.out.println(resultSet.getFloat(3));
//	        }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

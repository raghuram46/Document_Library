package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).buildSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			Employee e1 = new Employee();
			e1.setId(1);
			e1.setFirstName("3");
			e1.setLastName("3");
			
			session.beginTransaction();
			System.out.println("Saving employee");
			session.save(e1);
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}finally {
			factory.close();
		}
	}
}

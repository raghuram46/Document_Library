package com;

public class Address {

	private int id;
	private int doorNo;
	private String street;
	private String pinCode;

	public Address() {
		super();
	}

	public Address(int id, int doorNo, String street, String pinCode) {
		super();
		this.id = id;
		this.doorNo = doorNo;
		this.street = street;
		this.pinCode = pinCode;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

}

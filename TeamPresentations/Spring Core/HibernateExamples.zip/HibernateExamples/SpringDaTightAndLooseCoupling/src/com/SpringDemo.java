package com;

public class SpringDemo {

	public static void main(String[] args) {
		
		Employee employee = new Employee();
		employee.setId(1);
		employee.setName("Pawan");
		employee.setSalary(1000f);
		
		System.out.println(employee.getId());
		System.out.println(employee.getName());
		System.out.println(employee.getSalary());
		
		//Address address = new Address(11,25,"anna nagar","624250");
		
		System.out.println(employee.getAddress());
		

	}

}

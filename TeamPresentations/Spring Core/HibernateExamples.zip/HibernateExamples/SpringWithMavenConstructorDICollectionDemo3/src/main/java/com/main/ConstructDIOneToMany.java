package com.main;



import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Address;
import com.model.Employee;

public class ConstructDIOneToMany {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/config/springconfig.xml");
		
		 Employee employee1 = (Employee) applicationContext.getBean("employee");
		 
		 System.out.println("Employee Details");
		 System.out.println(employee1.getId());
		 System.out.println(employee1.getName());
		 System.out.println(employee1.getSalary());
		 System.out.println("--------------------");
		 System.out.println("Employee Address Details");
		 List<Address> addresses =  employee1.getAddresses();
		 int id = 0;
		 for(Address address:addresses) {
			 System.out.println("Address " + id);
			 System.out.println(address.getAddId());
			 System.out.println(address.getDoorNo());
			 System.out.println(address.getStreet());
			 System.out.println(address.getPinCode());
			 System.out.println("//////////////");
			 id++;
		 }

	}

}

package com.model;

public class Address {

	private int addId;
	private String doorNo;
	private String street;
	private String pinCode;

	public Address() {
		super();
	}

	public Address(int addId, String doorNo, String street, String pinCode) {
		super();
		this.addId = addId;
		this.doorNo = doorNo;
		this.street = street;
		this.pinCode = pinCode;
	}

	public int getAddId() {
		return addId;
	}

	public void setAddId(int addId) {
		this.addId = addId;
	}

	public String getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

}

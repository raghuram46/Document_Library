package com.example.config;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.example.dao.PersonDaoImpl;

@Configuration
@ComponentScan(basePackages = {"com.example.dao","com.example.model"})
public class BeanConfiguration {

	@Bean
	public PersonDaoImpl createPersonDaoImpl() {
		return new PersonDaoImpl();
	}

}

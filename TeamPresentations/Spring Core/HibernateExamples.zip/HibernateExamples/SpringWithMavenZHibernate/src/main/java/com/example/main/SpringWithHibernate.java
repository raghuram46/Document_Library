package com.example.main;

import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.dao.PersonDaoImpl;
import com.example.model.Person;

public class SpringWithHibernate {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.example.config");
		PersonDaoImpl personDao = applicationContext.getBean(PersonDaoImpl.class);
		
		Person person = new Person();
		person.setName("Pankaj"); person.setCountry("India");
		personDao.save(person);
	}

}

package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.EmployeeDao;
import com.model.Employee;

public class MainByJDBCTemplate {

	public static void main(String[] args) {
		 ApplicationContext ctx=new ClassPathXmlApplicationContext("com/config/springconfig.xml");  
	      
		    Employee emp=(Employee)ctx.getBean("employee");  
		    
		    EmployeeDao dao= (EmployeeDao) ctx.getBean("edao");  	    
		   
		    int status = dao.saveEmployee(emp);  
		    System.out.println(status);  

	}

}

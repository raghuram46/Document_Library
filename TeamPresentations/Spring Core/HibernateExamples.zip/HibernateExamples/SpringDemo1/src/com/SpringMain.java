package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class SpringMain {
	public static void main(String[] args) {

		//BasicConfigurator.configure();
		
		Resource resource=new ClassPathResource("web.xml");  
	    BeanFactory factory=new XmlBeanFactory(resource);  
	      
	    Student student=(Student)factory.getBean("studentbean");  
	    student.displayInfo();  
	    System.out.println(student);
	    
	    System.err.println("////////////////////////////////");
	    System.err.println("Bean Factory Method is Deprecated");
	    
	    ApplicationContext applicationContext = new ClassPathXmlApplicationContext("web.xml");
	    
	    Student student1 = (Student) applicationContext.getBean("studentbean");
	    student1.displayInfo(); 
	    System.out.println(student1);
	}
}

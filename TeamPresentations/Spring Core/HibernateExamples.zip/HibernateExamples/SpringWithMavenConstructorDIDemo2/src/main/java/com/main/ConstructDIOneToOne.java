package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Employee;

public class ConstructDIOneToOne {

	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/config/springconfig.xml");
		
		 Employee employee1 = (Employee) applicationContext.getBean("employee");
		 
		 System.out.println("Employee Details");
		 System.out.println(employee1.getId());
		 System.out.println(employee1.getName());
		 System.out.println(employee1.getSalary());
		 System.out.println("Employee Address Details");
		 System.out.println(employee1.getAddress().getAddId());
		 System.out.println(employee1.getAddress().getDoorNo());
		 System.out.println(employee1.getAddress().getStreet());
		 System.out.println(employee1.getAddress().getPinCode());
	}
}

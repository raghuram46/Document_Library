package com.main;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Employee;

public class SpringMainMethod {

	public static void main(String[] args) {
		//Application context is the InversionOfControl container
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/config/springconfig.xml");
		Employee employee1 = (Employee) applicationContext.getBean("employee1");
		//Employee employee1copy = (Employee) applicationContext.getBean("employee1");
		Employee employee2 = (Employee) applicationContext.getBean("employee2");
		System.out.println(employee1.getId());
		System.out.println(employee1.getName());
		System.out.println(employee1.getSalary());
		System.out.println(employee1);
		//System.out.println(employee1copy);
		System.out.println("*********************");
		System.out.println(employee2.getId());
		System.out.println(employee2.getName());
		System.out.println(employee2.getSalary());
		System.out.println(employee2);
		
	}

}

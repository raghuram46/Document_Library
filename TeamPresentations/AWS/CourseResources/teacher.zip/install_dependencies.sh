#!/bin/bash

sudo amazon-linux-extras install java-openjdk11
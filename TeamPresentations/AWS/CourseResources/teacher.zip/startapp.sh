#!/bin/bash
echo 'Starting my app'
java -jar /tmp/teacher-0.0.1-SNAPSHOT.jar &

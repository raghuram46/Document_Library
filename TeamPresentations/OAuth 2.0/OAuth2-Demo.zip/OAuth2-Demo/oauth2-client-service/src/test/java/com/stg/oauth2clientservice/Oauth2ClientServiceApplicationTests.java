package com.stg.oauth2clientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2ClientServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

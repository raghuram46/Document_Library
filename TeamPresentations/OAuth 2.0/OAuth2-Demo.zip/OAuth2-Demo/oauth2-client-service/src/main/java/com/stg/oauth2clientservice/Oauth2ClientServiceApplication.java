package com.stg.oauth2clientservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2ClientServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Oauth2ClientServiceApplication.class, args);
	}

}

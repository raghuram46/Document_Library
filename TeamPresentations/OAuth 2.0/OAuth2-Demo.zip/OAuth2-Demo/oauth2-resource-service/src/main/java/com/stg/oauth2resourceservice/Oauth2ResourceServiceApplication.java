package com.stg.oauth2resourceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2ResourceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Oauth2ResourceServiceApplication.class, args);
	}

}

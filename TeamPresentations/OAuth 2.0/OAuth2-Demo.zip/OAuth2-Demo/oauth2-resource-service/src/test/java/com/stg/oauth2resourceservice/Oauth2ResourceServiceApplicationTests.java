package com.stg.oauth2resourceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2ResourceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
